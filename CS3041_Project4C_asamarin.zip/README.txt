CS3041 Aleksandr Samarin README.txt 04/25/2024

How to run website:
Provided in the submission are the html files, style.css, and all the .jpg's needed for the a successful run.

To open the website. I ahve uploaded my files to a private Github repository with the link:
https://github.com/asamarin22/projectXplor

Alternative way (recommended):
Download and extract the .html, .css, .jpg files to one file and open on a desired IDE. I used Visual Studio Code to build the website.

When you have the extracted folder, open the index.html in the browser of your choice. This should then allow you to navigate through the pages freely.

State of the Hi-Fidelity prototype from this assignment:
	As it is the hi-fi prototype i decided to code the website to a certain degree of completion. I included colors and fonts to match those in my moodboard. I have also implemented some feature upgrades from the last user evaluation. 
	
	As for features and pages that have not been fully implemented:
		-Any settings or login page that I desired is non functional.
		-To save time on creating html pages, I created the design for the addFlightInfo
			This is because train, roadtrip, hotel, and other will have similar pages to go to.
			These pages will also eventually have the same result once the form is submitted.
		-As of right now, the program only holds one trip on the myTravelHub page
		

Additional Note: I emailed Prof. Lane Harrison about resubmitting on 04/26 as my addTrip.html did not have the correct stylesheet linked.